export class GalleryPhoto {

  constructor(
    public description: string,
    public imageURL: string
  ) { }

}
