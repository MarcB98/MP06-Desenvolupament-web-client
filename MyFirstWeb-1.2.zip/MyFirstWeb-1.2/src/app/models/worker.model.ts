export class CompanyWorker {

  constructor(
    public name: string,
    public imageURL: string
  ) { }

}
